<?php

return [
    'site_title' => 'Conference Event',
];
