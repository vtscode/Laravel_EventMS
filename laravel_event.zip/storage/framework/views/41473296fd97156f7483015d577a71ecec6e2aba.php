<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.price.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.prices.update", [$price->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                <label for="name"><?php echo e(trans('cruds.price.fields.name')); ?>*</label>
                <input type="text" id="name" name="name" class="form-control" value="<?php echo e(old('name', isset($price) ? $price->name : '')); ?>" required>
                <?php if($errors->has('name')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('name')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.price.fields.name_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('price') ? 'has-error' : ''); ?>">
                <label for="price"><?php echo e(trans('cruds.price.fields.price')); ?>*</label>
                <input type="number" id="price" name="price" class="form-control" value="<?php echo e(old('price', isset($price) ? $price->price : '')); ?>" step="0.01" required>
                <?php if($errors->has('price')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('price')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.price.fields.price_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('amenities') ? 'has-error' : ''); ?>">
                <label for="amenities"><?php echo e(trans('cruds.price.fields.amenities')); ?>

                    <span class="btn btn-info btn-xs select-all"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all"><?php echo e(trans('global.deselect_all')); ?></span></label>
                <select name="amenities[]" id="amenities" class="form-control select2" multiple="multiple">
                    <?php $__currentLoopData = $amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $amenities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((in_array($id, old('amenities', [])) || isset($price) && $price->amenities->contains($id)) ? 'selected' : ''); ?>><?php echo e($amenities); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('amenities')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('amenities')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.price.fields.amenities_helper')); ?>

                </p>
            </div>
            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lee/Desktop/laravel/Laravel_Event/resources/views/admin/prices/edit.blade.php ENDPATH**/ ?>