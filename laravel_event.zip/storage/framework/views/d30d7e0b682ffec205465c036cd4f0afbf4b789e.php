<section id="subscribe">
  <div class="container wow fadeInUp">
    <div class="section-header">
      <h2>Newsletter</h2>
      <p>Rerum numquam illum recusandae quia mollitia consequatur.</p>
    </div>

    <form method="POST" action="#">
      <div class="form-row justify-content-center">
        <div class="col-auto">
          <input type="text" class="form-control" placeholder="Enter your Email">
        </div>
        <div class="col-auto">
          <button type="submit">Subscribe</button>
        </div>
      </div>
    </form>

  </div>
</section>
<?php /**PATH /var/www/html/Laravel_Event/resources/views/sections/subscribe.blade.php ENDPATH**/ ?>