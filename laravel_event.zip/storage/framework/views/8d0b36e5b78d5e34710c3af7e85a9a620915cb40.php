<header id="header"<?php if(Route::current()->getName() != 'home'): ?> class="header-fixed"<?php endif; ?>>
  <div class="container">

    <div id="logo" class="pull-left">
      <h1>
        <a href="<?php echo e(route('home.index')); ?>#intro">
          <span><i class="fa fa-map-marker" aria-hidden="true"></i></span>
          <?php echo e(env('APP_NAME', 'The Event')); ?>

        </a>
      </h1>
    </div>

    <nav id="nav-menu-container">
      <ul class="nav-menu">
        <li class="menu-active"><a href="<?php echo e(Route::current()->getName() != 'home.index' ? route('home.index') : ''); ?>#intro">Home</a></li>
        <li><a href="<?php echo e(Route::current()->getName() != 'home.index' ? route('home.index') : ''); ?>#about">About</a></li>
        <li><a href="<?php echo e(Route::current()->getName() != 'home.index' ? route('home.index') : ''); ?>#speakers">Speakers</a></li>
        <li><a href="<?php echo e(Route::current()->getName() != 'home.index' ? route('home.index') : ''); ?>#schedule">Schedule</a></li>
        <li><a href="<?php echo e(Route::current()->getName() != 'home.index' ? route('home.index') : ''); ?>#venue">Venue</a></li>
        <li><a href="<?php echo e(Route::current()->getName() != 'home.index' ? route('home.index') : ''); ?>#hotels">Hotels</a></li>
        <li><a href="<?php echo e(Route::current()->getName() != 'home.index' ? route('home.index') : ''); ?>#gallery">Gallery</a></li>
        <li><a href="<?php echo e(Route::current()->getName() != 'home.index' ? route('home.index') : ''); ?>#supporters">Sponsors</a></li>
        <li><a href="<?php echo e(Route::current()->getName() != 'home.index' ? route('home.index') : ''); ?>#contact">Contact</a></li>
        <li class="buy-tickets"><a href="<?php echo e(Route::current()->getName() != 'home.index' ? route('home.index') : ''); ?>#buy-tickets">Buy Tickets</a></li>
      </ul>
    </nav>
  </div>
</header>
<?php /**PATH /home/lee/Desktop/laravel/Laravel_Event/resources/views/partials/header.blade.php ENDPATH**/ ?>