<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.sponsor.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.sponsors.update", [$sponsor->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                <label for="name"><?php echo e(trans('cruds.sponsor.fields.name')); ?>*</label>
                <input type="text" id="name" name="name" class="form-control" value="<?php echo e(old('name', isset($sponsor) ? $sponsor->name : '')); ?>" required>
                <?php if($errors->has('name')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('name')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.sponsor.fields.name_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('logo') ? 'has-error' : ''); ?>">
                <label for="logo"><?php echo e(trans('cruds.sponsor.fields.logo')); ?></label>
                <div class="needsclick dropzone" id="logo-dropzone">

                </div>
                <?php if($errors->has('logo')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('logo')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.sponsor.fields.logo_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('link') ? 'has-error' : ''); ?>">
                <label for="link"><?php echo e(trans('cruds.sponsor.fields.link')); ?></label>
                <input type="text" id="link" name="link" class="form-control" value="<?php echo e(old('link', isset($sponsor) ? $sponsor->link : '')); ?>">
                <?php if($errors->has('link')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('link')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.sponsor.fields.link_helper')); ?>

                </p>
            </div>
            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    Dropzone.options.logoDropzone = {
    url: '<?php echo e(route('admin.sponsors.storeMedia')); ?>',
    maxFilesize: 2, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').find('input[name="logo"]').remove()
      $('form').append('<input type="hidden" name="logo" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="logo"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($sponsor) && $sponsor->logo): ?>
      var file = <?php echo json_encode($sponsor->logo); ?>

          this.options.addedfile.call(this, file)
      this.options.thumbnail.call(this, file, file.url)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="logo" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
    error: function (file, response) {
        if ($.type(response) === 'string') {
            var message = response //dropzone sends it's own error messages in string
        } else {
            var message = response.errors.file
        }
        file.previewElement.classList.add('dz-error')
        _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
        _results = []
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            node = _ref[_i]
            _results.push(node.textContent = message)
        }

        return _results
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u7630949/public_html/sandbox/eventpedia/resources/views/admin/sponsors/edit.blade.php ENDPATH**/ ?>