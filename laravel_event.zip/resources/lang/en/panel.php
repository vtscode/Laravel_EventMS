<?php

return [
    'site_title' => env('APP_NAME','Eventpedia'),
];
